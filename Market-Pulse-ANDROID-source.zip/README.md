# Market Pulse Android

Native Android companion for the Market Pulse dashboard.

## Included
- Foreground 24/7 RSS monitoring
- Critical Gold, Crypto, Forex, Oil and geopolitical headline detection
- High-priority notification with repeating vibration every five seconds until acknowledged
- Monitoring restart after device reboot
- One-tap access to the English Market Pulse dashboard

## Install
Download the APK from the latest successful **Build Android APK** GitHub Actions run.

After installation, allow notifications, press **Start 24/7 Monitoring**, and allow unrestricted
battery/background usage. Android may stop monitoring if the user force-stops the application.
