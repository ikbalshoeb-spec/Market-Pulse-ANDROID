package com.shoaib.marketpulse;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String DASHBOARD = "https://shoeb-market-pulse.ikbalshoeb.chatgpt.site";
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(42, 70, 42, 42); root.setBackgroundColor(Color.rgb(7,17,31));
        root.addView(text("MARKET PULSE", 30, Color.rgb(242,190,46)));
        root.addView(text("24/7 Critical Market News Monitor", 17, Color.WHITE));
        root.addView(text("Alerts for Gold, Crypto, Forex and Oil. Critical headlines repeat vibration until acknowledged.", 15, Color.LTGRAY));
        root.addView(button("START 24/7 MONITORING", v -> startMonitor()));
        root.addView(button("ALLOW BACKGROUND OPERATION", v -> batterySettings()));
        root.addView(button("OPEN MARKET PULSE DASHBOARD", v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DASHBOARD)))));
        root.addView(button("STOP MONITORING", v -> stopService(new Intent(this, MarketMonitorService.class))));
        setContentView(root);
    }
    private TextView text(String s, int sp, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.CENTER); v.setPadding(8, 12, 8, 20); return v;
    }
    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this); b.setText(s); b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 16, 0, 0); b.setLayoutParams(p); return b;
    }
    private void startMonitor() {
        Intent i = new Intent(this, MarketMonitorService.class).setAction(MarketMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    private void batterySettings() {
        try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
    }
}
