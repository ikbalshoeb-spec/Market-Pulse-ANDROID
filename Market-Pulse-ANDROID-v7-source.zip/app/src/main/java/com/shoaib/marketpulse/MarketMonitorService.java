package com.shoaib.marketpulse;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MarketMonitorService extends Service {
    public static final String ACTION_START = "com.shoaib.marketpulse.START";
    public static final String ACTION_ACK = "com.shoaib.marketpulse.ACK";
    private static final String MONITOR_CHANNEL = "monitoring";
    private static final String ALERT_CHANNEL = "critical_alerts";
    private static final int FOREGROUND_ID = 100;
    private static final int ALERT_ID = 911;
    private static final long POLL_MS = 60_000L;
    private static final long PRICE_POLL_MS = 5_000L;
    private static final long PRICE_WINDOW_MS = 60_000L;
    private static final long PRICE_ALERT_COOLDOWN_MS = 3 * 60_000L;
    private static final long MAX_AGE_MS = 20 * 60_000L;
    private static final String DASHBOARD = "https://shoeb-market-pulse.ikbalshoeb.chatgpt.site";
    private static final String[] FEEDS = {
        "https://feeds.bloomberg.com/markets/news.rss",
        "https://www.cnbc.com/id/100003114/device/rss/rss.html",
        "https://feeds.bbci.co.uk/news/business/rss.xml",
        "https://www.theguardian.com/business/rss"
    };
    private static final String[] EXCLUDED_NEWS = {
        "gold medal","silver medal","bronze medal","olympic","paralympic","championship",
        "world cup","football","soccer","cricket","athlete","tournament","jewellery","jewelry",
        "edible oil","cooking oil","palm oil","olive oil","sunflower oil","soybean oil","vegetable oil"
    };

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final ScheduledExecutorService priceScheduler = Executors.newSingleThreadScheduledExecutor();
    private final ScheduledExecutorService alertScheduler = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private final Set<String> seen = Collections.synchronizedSet(new LinkedHashSet<>());
    private final Map<String, Deque<PriceSample>> priceHistory = new ConcurrentHashMap<>();
    private final Map<String, Long> lastPriceAlert = new ConcurrentHashMap<>();
    private volatile boolean alertActive;
    private ScheduledFuture<?> vibrationTask;
    private Vibrator vibrator;

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        startForeground(FOREGROUND_ID, monitorNotification("Starting live monitoring…"));
        scheduler.scheduleWithFixedDelay(this::pollAll, 0, POLL_MS, TimeUnit.MILLISECONDS);
        priceScheduler.scheduleWithFixedDelay(this::pollPrices, 1, PRICE_POLL_MS, TimeUnit.MILLISECONDS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && ACTION_ACK.equals(intent.getAction())) acknowledge();
        return START_STICKY;
    }

    private void pollAll() {
        List<Future<?>> tasks = new ArrayList<>();
        for (String feed : FEEDS) tasks.add(network.submit(() -> readFeed(feed)));
        for (Future<?> task : tasks) try { task.get(25, TimeUnit.SECONDS); } catch (Exception ignored) { task.cancel(true); }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(
            FOREGROUND_ID, monitorNotification("Live • checked " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())));
    }

    private void readFeed(String address) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection)new URL(address).openConnection();
            conn.setConnectTimeout(10_000); conn.setReadTimeout(15_000);
            conn.setRequestProperty("User-Agent", "MarketPulseAndroid/1.0");
            try (InputStream input = conn.getInputStream()) {
                XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
                p.setInput(input, null);
                boolean item = false; String title = null, link = null, date = null;
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String tag = p.getName().toLowerCase(Locale.US);
                        if ("item".equals(tag) || "entry".equals(tag)) { item = true; title = link = date = null; }
                        else if (item && "title".equals(tag)) title = p.nextText();
                        else if (item && ("pubdate".equals(tag) || "published".equals(tag) || "updated".equals(tag))) date = p.nextText();
                        else if (item && "link".equals(tag)) {
                            String href = p.getAttributeValue(null, "href");
                            link = href != null ? href : p.nextText();
                        }
                    } else if (e == XmlPullParser.END_TAG && item &&
                            ("item".equalsIgnoreCase(p.getName()) || "entry".equalsIgnoreCase(p.getName()))) {
                        process(title, link, date); item = false;
                    }
                }
            }
        } catch (Exception ignored) { } finally { if (conn != null) conn.disconnect(); }
    }

    private void pollPrices() {
        try { readBinancePrices(); } catch (Exception ignored) { }
        try { readGoldPrice(); } catch (Exception ignored) { }
        try { readYahooOilPrice(); } catch (Exception ignored) { }
    }

    private void readBinancePrices() throws Exception {
        String address = "https://api.binance.com/api/v3/ticker/price?symbols=%5B%22BTCUSDT%22,%22ETHUSDT%22,%22XRPUSDT%22%5D";
        JSONArray rows = new JSONArray(readJson(address));
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.getJSONObject(i);
            String symbol = row.getString("symbol");
            double price = row.getDouble("price");
            if ("BTCUSDT".equals(symbol)) recordPrice("BTC", price, 500.0);
            else if ("ETHUSDT".equals(symbol)) recordPrice("ETH", price, 50.0);
            else if ("XRPUSDT".equals(symbol)) recordPrice("XRP", price, 0.05);
        }
    }

    private void readGoldPrice() throws Exception {
        JSONObject data = new JSONObject(readJson("https://api.gold-api.com/price/XAU"));
        double price = data.optDouble("price", Double.NaN);
        if (!Double.isNaN(price) && price > 0) recordPrice("GOLD", price, 10.0);
    }

    private void readYahooOilPrice() throws Exception {
        String address = "https://query1.finance.yahoo.com/v8/finance/chart/CL%3DF?range=1d&interval=1m&includePrePost=true";
        JSONObject data = new JSONObject(readJson(address));
        JSONObject meta = data.getJSONObject("chart").getJSONArray("result").getJSONObject(0).getJSONObject("meta");
        double price = meta.optDouble("regularMarketPrice", Double.NaN);
        if (!Double.isNaN(price) && price > 0) recordPrice("US OIL", price, 1.0);
    }

    private String readJson(String address) throws Exception {
        HttpURLConnection conn = (HttpURLConnection)new URL(address).openConnection();
        try {
            conn.setConnectTimeout(4_000); conn.setReadTimeout(4_000);
            conn.setRequestProperty("User-Agent", "MarketPulseAndroid/2.4");
            conn.setRequestProperty("Cache-Control", "no-cache");
            if (conn.getResponseCode() < 200 || conn.getResponseCode() >= 300)
                throw new IllegalStateException("Price feed " + conn.getResponseCode());
            StringBuilder out = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line; while ((line = reader.readLine()) != null) out.append(line);
            }
            return out.toString();
        } finally { conn.disconnect(); }
    }

    private void recordPrice(String symbol, double price, double threshold) {
        long now = System.currentTimeMillis();
        Deque<PriceSample> samples = priceHistory.computeIfAbsent(symbol, key -> new ConcurrentLinkedDeque<>());
        samples.addLast(new PriceSample(now, price));
        while (!samples.isEmpty() && now - samples.peekFirst().time > PRICE_WINDOW_MS) samples.pollFirst();
        PriceSample oldest = samples.peekFirst();
        if (oldest == null || oldest == samples.peekLast()) return;
        double move = price - oldest.price;
        if (Math.abs(move) < threshold) return;
        long last = lastPriceAlert.getOrDefault(symbol, 0L);
        if (now - last < PRICE_ALERT_COOLDOWN_MS) return;
        lastPriceAlert.put(symbol, now);
        long seconds = Math.max(1, (now - oldest.time) / 1000);
        double percent = oldest.price == 0 ? 0 : Math.abs(move / oldest.price) * 100;
        String direction = move > 0 ? "UP" : "DOWN";
        String amount = ("XRP".equals(symbol) ? String.format(Locale.US, "$%.4f", Math.abs(move)) : String.format(Locale.US, "$%.2f", Math.abs(move)));
        String detail = String.format(Locale.US, "%s %s %s in %ds (%.2f%%)", symbol, direction, amount, seconds, percent);
        showAlert("IMPULSIVE MARKET MOVE", detail, DASHBOARD);
    }

    private void process(String title, String link, String rawDate) {
        if (title == null || !isHighImpactMarketNews(title) || !isFresh(rawDate)) return;
        String key = title.trim().toLowerCase(Locale.US);
        String storedKey = Integer.toHexString(key.hashCode());
        if (getSharedPreferences("seen_news", MODE_PRIVATE).getBoolean(storedKey, false)) return;
        if (!seen.add(key)) return;
        getSharedPreferences("seen_news", MODE_PRIVATE).edit().putBoolean(storedKey, true).apply();
        while (seen.size() > 300) seen.remove(seen.iterator().next());
        showCritical(title.trim(), link);
    }

    private boolean isHighImpactMarketNews(String title) {
        String t = title.toLowerCase(Locale.US);
        for (String phrase : EXCLUDED_NEWS) if (t.contains(phrase)) return false;

        // Scheduled macro events that routinely move USD, yields, Gold and Crypto.
        boolean usMacro = containsAny(t, "federal reserve", "fed rate", "fomc", "powell") &&
            containsAny(t, "rate", "hike", "cut", "decision", "statement", "minutes", "hawkish", "dovish");
        boolean majorData = containsAny(t, "us cpi", "u.s. cpi", "core cpi", "pce inflation", "nonfarm payroll", "non-farm payroll", "nfp", "us jobs report", "u.s. jobs report") &&
            containsAny(t, "rises", "falls", "unexpected", "surprise", "above", "below", "hotter", "cooler", "release", "data");

        // Oil alerts require crude-market language, never the word 'oil' by itself.
        boolean crudeContext = containsAny(t, "crude oil", "wti", "brent", "opec", "oil futures", "oil prices", "oil supply", "oil production", "oil inventory", "oil inventories", "refinery", "barrel");
        boolean crudeShock = crudeContext && containsAny(t, "output cut", "production cut", "output hike", "production increase", "emergency meeting", "decision", "unexpected draw", "unexpected build", "supply disruption", "outage", "embargo", "sanction", "attack", "shutdown");

        boolean cryptoContext = containsAny(t, "bitcoin", "btc", "ethereum", "ether", "eth", "xrp", "crypto", "cryptocurrency", "digital asset");
        boolean cryptoShock = cryptoContext && containsAny(t, "etf approved", "etf approval", "etf rejected", "ban", "banned", "crackdown", "sec lawsuit", "regulation", "hack", "hacked", "exploit", "liquidation", "bankruptcy", "default", "outage");

        // Geopolitical alerts must contain both a market-sensitive region and a real escalation/de-escalation.
        boolean geoRegion = containsAny(t, "iran", "israel", "strait of hormuz", "hormuz", "persian gulf", "saudi arabia", "russia", "ukraine");
        boolean geoEvent = containsAny(t, "missile", "airstrike", "air strike", "drone attack", "military attack", "invasion", "ceasefire", "war declared", "shipping blocked", "tanker attacked", "nuclear site", "sanctions imposed");

        return usMacro || majorData || crudeShock || cryptoShock || (geoRegion && geoEvent);
    }

    private boolean containsAny(String text, String... phrases) {
        for (String phrase : phrases) if (text.contains(phrase)) return true;
        return false;
    }

    private boolean isFresh(String raw) {
        if (raw == null || raw.isEmpty()) return false;
        String[] patterns = {"EEE, dd MMM yyyy HH:mm:ss Z","EEE, dd MMM yyyy HH:mm Z",
            "yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String pattern : patterns) try {
            SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = f.parse(raw.trim());
            return d != null && Math.abs(System.currentTimeMillis() - d.getTime()) <= MAX_AGE_MS;
        } catch (Exception ignored) { }
        return false;
    }

    private void showCritical(String title, String link) {
        showAlert("DANGER • MARKET-MOVING NEWS", title, link);
    }

    private void showAlert(String heading, String title, String link) {
        alertActive = true;
        Intent open = new Intent(this, MainActivity.class);
        open.setData(Uri.parse(link == null || link.isEmpty() ? DASHBOARD : link));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent ack = new Intent(this, MarketMonitorService.class).setAction(ACTION_ACK);
        PendingIntent ackPi = PendingIntent.getService(this, 2, ack, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(com.shoaib.marketpulse.R.drawable.ic_stat_alert)
            .setContentTitle(heading)
            .setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title))
            .setColor(Color.RED).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true).setAutoCancel(false).setContentIntent(openPi)
            .addAction(0, "OPEN NEWS", openPi).addAction(0, "ACKNOWLEDGE", ackPi).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(ALERT_ID, n);
        vibrateUntilAcknowledged();
    }

    private static class PriceSample {
        final long time; final double price;
        PriceSample(long time, double price) { this.time = time; this.price = price; }
    }

    private void vibrateUntilAcknowledged() {
        if (vibrationTask != null && !vibrationTask.isDone()) return;
        vibrationTask = alertScheduler.scheduleAtFixedRate(() -> {
            if (!alertActive) return;
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(900, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(900);
        }, 0, 5, TimeUnit.SECONDS);
    }

    private void acknowledge() {
        alertActive = false;
        if (vibrationTask != null) { vibrationTask.cancel(false); vibrationTask = null; }
        if (vibrator != null) vibrator.cancel();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(ALERT_ID);
    }

    private Notification monitorNotification(String status) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, MONITOR_CHANNEL)
            .setSmallIcon(com.shoaib.marketpulse.R.drawable.ic_stat_alert)
            .setContentTitle("Market Pulse is monitoring").setContentText(status)
            .setOngoing(true).setContentIntent(pi).build();
    }

    private void createChannels() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel monitor = new NotificationChannel(MONITOR_CHANNEL, "24/7 Monitoring", NotificationManager.IMPORTANCE_LOW);
        NotificationChannel alert = new NotificationChannel(ALERT_CHANNEL, "Critical Market Alerts", NotificationManager.IMPORTANCE_HIGH);
        alert.enableVibration(false); alert.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(monitor); nm.createNotificationChannel(alert);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        acknowledge(); scheduler.shutdownNow(); priceScheduler.shutdownNow(); alertScheduler.shutdownNow(); network.shutdownNow(); super.onDestroy();
    }
}
