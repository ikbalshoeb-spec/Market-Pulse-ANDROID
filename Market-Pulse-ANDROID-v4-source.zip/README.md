# Market Pulse Android

Single-app Android edition of Market Pulse. The complete dashboard runs full-screen
inside the APK; users are not sent to Chrome.

## Included
- Foreground 24/7 RSS monitoring
- Critical Gold, Crypto, Forex, Oil and geopolitical headline detection
- High-priority notification with repeating vibration every five seconds until acknowledged
- Monitoring restart after device reboot
- Full-screen in-app News Desk, markets, calendar and dashboard
- In-app navigation, refresh, cache and settings

## Install
Download the APK from the latest successful **Build Android APK** GitHub Actions run.

After installation, allow notifications, press **Start 24/7 Monitoring**, and allow unrestricted
battery/background usage. Android may stop monitoring if the user force-stops the application.
