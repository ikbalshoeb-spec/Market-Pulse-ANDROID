package com.shoaib.marketpulse;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent in) {
        Intent service = new Intent(c, MarketMonitorService.class).setAction(MarketMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(service); else c.startService(service);
    }
}
