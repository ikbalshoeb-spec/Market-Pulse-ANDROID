package com.shoaib.marketpulse;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MarketMonitorService extends Service {
    public static final String ACTION_START = "com.shoaib.marketpulse.START";
    public static final String ACTION_ACK = "com.shoaib.marketpulse.ACK";
    private static final String MONITOR_CHANNEL = "monitoring";
    private static final String ALERT_CHANNEL = "critical_alerts";
    private static final int FOREGROUND_ID = 100;
    private static final int ALERT_ID = 911;
    private static final long POLL_MS = 60_000L;
    private static final long MAX_AGE_MS = 20 * 60_000L;
    private static final String DASHBOARD = "https://shoeb-market-pulse.ikbalshoeb.chatgpt.site";
    private static final String[] FEEDS = {
        "https://feeds.bloomberg.com/markets/news.rss",
        "https://www.cnbc.com/id/100003114/device/rss/rss.html",
        "https://feeds.bbci.co.uk/news/business/rss.xml",
        "https://www.theguardian.com/business/rss"
    };
    private static final String[] CRITICAL = {
        "war","attack","strike","missile","invasion","emergency","rate decision",
        "fed rate","federal reserve","opec decision","sanction","ceasefire","tariff",
        "cpi","inflation","payroll","oil supply","hormuz","central bank","interest rate"
    };

    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final ExecutorService network = Executors.newFixedThreadPool(3);
    private final Set<String> seen = Collections.synchronizedSet(new LinkedHashSet<>());
    private volatile boolean alertActive;
    private ScheduledFuture<?> vibrationTask;
    private Vibrator vibrator;

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        startForeground(FOREGROUND_ID, monitorNotification("Starting live monitoring…"));
        scheduler.scheduleWithFixedDelay(this::pollAll, 0, POLL_MS, TimeUnit.MILLISECONDS);
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent != null && ACTION_ACK.equals(intent.getAction())) acknowledge();
        return START_STICKY;
    }

    private void pollAll() {
        List<Future<?>> tasks = new ArrayList<>();
        for (String feed : FEEDS) tasks.add(network.submit(() -> readFeed(feed)));
        for (Future<?> task : tasks) try { task.get(25, TimeUnit.SECONDS); } catch (Exception ignored) { task.cancel(true); }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(
            FOREGROUND_ID, monitorNotification("Live • checked " + new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date())));
    }

    private void readFeed(String address) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection)new URL(address).openConnection();
            conn.setConnectTimeout(10_000); conn.setReadTimeout(15_000);
            conn.setRequestProperty("User-Agent", "MarketPulseAndroid/1.0");
            try (InputStream input = conn.getInputStream()) {
                XmlPullParser p = XmlPullParserFactory.newInstance().newPullParser();
                p.setInput(input, null);
                boolean item = false; String title = null, link = null, date = null;
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String tag = p.getName().toLowerCase(Locale.US);
                        if ("item".equals(tag) || "entry".equals(tag)) { item = true; title = link = date = null; }
                        else if (item && "title".equals(tag)) title = p.nextText();
                        else if (item && ("pubdate".equals(tag) || "published".equals(tag) || "updated".equals(tag))) date = p.nextText();
                        else if (item && "link".equals(tag)) {
                            String href = p.getAttributeValue(null, "href");
                            link = href != null ? href : p.nextText();
                        }
                    } else if (e == XmlPullParser.END_TAG && item &&
                            ("item".equalsIgnoreCase(p.getName()) || "entry".equalsIgnoreCase(p.getName()))) {
                        process(title, link, date); item = false;
                    }
                }
            }
        } catch (Exception ignored) { } finally { if (conn != null) conn.disconnect(); }
    }

    private void process(String title, String link, String rawDate) {
        if (title == null || !isCritical(title) || !isFresh(rawDate)) return;
        String key = title.trim().toLowerCase(Locale.US);
        String storedKey = Integer.toHexString(key.hashCode());
        if (getSharedPreferences("seen_news", MODE_PRIVATE).getBoolean(storedKey, false)) return;
        if (!seen.add(key)) return;
        getSharedPreferences("seen_news", MODE_PRIVATE).edit().putBoolean(storedKey, true).apply();
        while (seen.size() > 300) seen.remove(seen.iterator().next());
        showCritical(title.trim(), link);
    }

    private boolean isCritical(String title) {
        String t = title.toLowerCase(Locale.US);
        for (String word : CRITICAL) if (t.contains(word)) return true;
        return false;
    }

    private boolean isFresh(String raw) {
        if (raw == null || raw.isEmpty()) return false;
        String[] patterns = {"EEE, dd MMM yyyy HH:mm:ss Z","EEE, dd MMM yyyy HH:mm Z",
            "yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String pattern : patterns) try {
            SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = f.parse(raw.trim());
            return d != null && Math.abs(System.currentTimeMillis() - d.getTime()) <= MAX_AGE_MS;
        } catch (Exception ignored) { }
        return false;
    }

    private void showCritical(String title, String link) {
        alertActive = true;
        Intent open = new Intent(this, MainActivity.class);
        open.setData(Uri.parse(link == null || link.isEmpty() ? DASHBOARD : link));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent ack = new Intent(this, MarketMonitorService.class).setAction(ACTION_ACK);
        PendingIntent ackPi = PendingIntent.getService(this, 2, ack, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(com.shoaib.marketpulse.R.drawable.ic_stat_alert)
            .setContentTitle("DANGER • MARKET-MOVING NEWS")
            .setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title))
            .setColor(Color.RED).setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true).setAutoCancel(false).setContentIntent(openPi)
            .addAction(0, "OPEN NEWS", openPi).addAction(0, "ACKNOWLEDGE", ackPi).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(ALERT_ID, n);
        vibrateUntilAcknowledged();
    }

    private void vibrateUntilAcknowledged() {
        if (vibrationTask != null && !vibrationTask.isDone()) return;
        vibrationTask = scheduler.scheduleAtFixedRate(() -> {
            if (!alertActive) return;
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(900, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(900);
        }, 0, 5, TimeUnit.SECONDS);
    }

    private void acknowledge() {
        alertActive = false;
        if (vibrationTask != null) { vibrationTask.cancel(false); vibrationTask = null; }
        if (vibrator != null) vibrator.cancel();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(ALERT_ID);
    }

    private Notification monitorNotification(String status) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, MONITOR_CHANNEL)
            .setSmallIcon(com.shoaib.marketpulse.R.drawable.ic_stat_alert)
            .setContentTitle("Market Pulse is monitoring").setContentText(status)
            .setOngoing(true).setContentIntent(pi).build();
    }

    private void createChannels() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel monitor = new NotificationChannel(MONITOR_CHANNEL, "24/7 Monitoring", NotificationManager.IMPORTANCE_LOW);
        NotificationChannel alert = new NotificationChannel(ALERT_CHANNEL, "Critical Market Alerts", NotificationManager.IMPORTANCE_HIGH);
        alert.enableVibration(false); alert.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(monitor); nm.createNotificationChannel(alert);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() {
        acknowledge(); scheduler.shutdownNow(); network.shutdownNow(); super.onDestroy();
    }
}
