package com.shoaib.marketpulse;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String DASHBOARD = "https://shoeb-market-pulse.ikbalshoeb.chatgpt.site";
    private WebView webView;
    private ProgressBar progress;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestNotificationPermission();
        createAppInterface();
        startMonitor();
        loadRequestedPage(getIntent());
    }

    private void createAppInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,17,31));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(22, 8, 10, 8);
        header.setBackgroundColor(Color.rgb(7,17,31));
        TextView title = new TextView(this);
        title.setText("MARKET PULSE"); title.setTextColor(Color.rgb(242,190,46));
        title.setTextSize(20); title.setTypeface(null, 1);
        header.addView(title, new LinearLayout.LayoutParams(0, 56, 1));
        header.addView(compactButton("↻", v -> webView.reload()));
        header.addView(compactButton("⚙", v -> showSettings()));
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); root.addView(progress, new LinearLayout.LayoutParams(-1, 5));

        webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setSupportZoom(false);
        ws.setUserAgentString(ws.getUserAgentString() + " MarketPulseAndroid/2.0");
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setBackgroundColor(Color.rgb(7,17,31));
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    view.loadUrl(url); return true;
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER); nav.setPadding(8, 5, 8, 5);
        nav.setBackgroundColor(Color.rgb(12,27,45));
        nav.addView(navButton("HOME", v -> webView.loadUrl(DASHBOARD)));
        nav.addView(navButton("BACK", v -> { if (webView.canGoBack()) webView.goBack(); }));
        nav.addView(navButton("REFRESH", v -> webView.reload()));
        nav.addView(navButton("SETTINGS", v -> showSettings()));
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private Button compactButton(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setTextSize(20);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT);
        b.setOnClickListener(listener); return b;
    }

    private Button navButton(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setTextSize(11);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT);
        b.setOnClickListener(listener);
        b.setLayoutParams(new LinearLayout.LayoutParams(0, 52, 1)); return b;
    }

    private void showSettings() {
        Dialog d = new Dialog(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(35, 30, 35, 30);
        box.setBackgroundColor(Color.rgb(12,27,45));
        TextView heading = new TextView(this);
        heading.setText("Market Pulse Settings"); heading.setTextSize(23);
        heading.setTextColor(Color.WHITE); heading.setPadding(0,0,0,15);
        box.addView(heading);
        box.addView(dialogButton("Start 24/7 Monitoring", v -> startMonitor()));
        box.addView(dialogButton("Allow Background Operation", v -> batterySettings()));
        box.addView(dialogButton("Clear Dashboard Cache", v -> { webView.clearCache(true); webView.reload(); }));
        box.addView(dialogButton("Close Settings", v -> d.dismiss()));
        d.setContentView(box); d.show();
        if (d.getWindow() != null) d.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private Button dialogButton(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text); b.setOnClickListener(listener);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0,7,0,7); b.setLayoutParams(p); return b;
    }

    private void loadRequestedPage(Intent intent) {
        Uri uri = intent == null ? null : intent.getData();
        webView.loadUrl(uri != null && ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme())) ? uri.toString() : DASHBOARD);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent); loadRequestedPage(intent);
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
    }

    private void startMonitor() {
        Intent i = new Intent(this, MarketMonitorService.class).setAction(MarketMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void batterySettings() {
        try { startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); }
        catch (Exception e) { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
